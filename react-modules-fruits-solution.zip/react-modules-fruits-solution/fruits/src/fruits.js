let fruits = [
  "🍇", "🍈", "🍉", "🍊", "🍋", "🍌", "🍍", "🍎",
  "🍏", "🍐", "🍒", "🍓", "🥝", "🍅", "🥑"
];


export default fruits;